package day1;

public class FirstJavaProgramme 
{
	public static void main(String args[])
	{
		System.out.println("Welcome to Java");
		System.out.println(10+20);
		System.out.println("10+20");
	}

}
