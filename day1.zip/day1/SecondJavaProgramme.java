package day1;

public class SecondJavaProgramme {

	public static void main(String[] args)
	{
		System.out.println("Hello.....");   //For getting the line Syso ctrl+Space 
		System.out.println("Hello.....");
		System.out.println("Hello.....");
		System.out.println("Hello.....");
		System.out.println("Hello.....");
	}

}
