package day2;

public class VariablesDemo {
	public static void main(String[] args) {
		//int a;  //declaration of variables
		//a=100;  //assignment
		/*int a=100; //declaration+assignment
		System.out.println(a);
		
		a=200;
		System.out.println(a);
		*/
		
		
		//Approach 1- if all the variables belongs to different data types.
		/*int a=100;
		int b=200;
		int c=300;*/
		
		//Approach2 - If all the variables are belongs to same data type.
		/*int a,b,c;
		a=100;
		b=200;
		c=300;*/
		
		//Approcah3 -- if all the variables are belongs to same datat type
		int a=100,b=200,c=300;
		
		System.out.println("The value of a is:"+a);
		System.out.println("the value of b is:"+b);
		System.out.println("The value of c is:"+c);
		
		System.out.println("a:"+a+" "+"b:"+b+" "+"c:"+c); //100 200 300
		
	}

}
